<?php

namespace App\Traits;

trait RegexPatterns
{
    //
}

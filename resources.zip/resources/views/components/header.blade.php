<div class="row main-top p-4">
    <div class="text-center">
        <h1 class="h1">
            {{ $title }}
        </h1>
    </div>
</div>
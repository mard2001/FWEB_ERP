<div class="w-100 overflow-auto" style="font-size: 14px;">
    <table class="mdl-data-table w-100 rmvBorder {{$class ?? ""}}" id="{{ $id ?? "getXmlData" }}">
        <thead class="text-white" style="background-color: #33336F;">
            <tr>
                {{ $td }}
            </tr>
        </thead>
        
    </table>
</div>
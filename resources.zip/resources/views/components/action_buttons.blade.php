<div class="main-content buttons w-100 overflow-auto mt-3 pe-4 d-flex align-items-center px-4" style="font-size: 14px;">
    <div class="btn d-flex justify-content-around px-2 align-items-center me-1" id="addBtn">
        <div class="btnImg me-2" id="addImg">
        </div>
        <span>Add new</span>
    </div>

    <div class="btn d-flex justify-content-around px-2 align-items-center me-1 actionBtn" id="csvShowBtn">
        <div class="btnImg me-2" id="dlImg">
        </div>
        <span>Download Template</span>
    </div>

    <div class="btn d-flex justify-content-around px-2 align-items-center me-1 actionBtn" id="csvUploadShowBtn">
        <div class="btnImg me-2" id="ulImg">
        </div>
        <span>Upload Template</span>
    </div>

</div>